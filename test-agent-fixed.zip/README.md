# Simple Test Agent

A basic Python agent for testing the AgentCredit platform.

## Features

- **Calculations**: Perform basic arithmetic operations (add, subtract, multiply, divide)
- **Text Analysis**: Analyze text for statistics (word count, character count, etc.)
- **Data Hashing**: Generate SHA256/MD5 hashes of data

## Usage

```python
from agent import SimpleAgent

agent = SimpleAgent("MyAgent")

# Process a calculation task
result = agent.process_task({
    'type': 'calculate',
    'payload': {'operation': 'add', 'a': 10, 'b': 5}
})

# Get agent statistics
stats = agent.get_stats()
```

## Running

```bash
python agent.py
```

## Security

This agent uses only Python standard library and has no external dependencies.
All operations are safe and don't involve file system access or network calls.
