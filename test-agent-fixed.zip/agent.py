"""
Simple AI Agent for Testing
A basic agent that can perform calculations and text analysis tasks.
"""
import json
import hashlib
from datetime import datetime

# Agent payment configuration
PAYMENT_ADDRESS = "0x1234567890123456789012345678901234567890"
WALLET_ADDRESS = "0x1234567890123456789012345678901234567890"


class SimpleAgent:
    """A simple agent that processes tasks and generates revenue."""

    def __init__(self, name="TestAgent"):
        self.name = name
        self.tasks_completed = 0
        self.total_revenue = 0.0

    def process_task(self, task_data):
        """
        Process a task and return the result.

        Args:
            task_data (dict): Task information containing 'type' and 'payload'

        Returns:
            dict: Result of the task processing
        """
        task_type = task_data.get('type', 'unknown')
        payload = task_data.get('payload', {})

        if task_type == 'calculate':
            result = self._calculate(payload)
        elif task_type == 'analyze_text':
            result = self._analyze_text(payload)
        elif task_type == 'hash_data':
            result = self._hash_data(payload)
        else:
            result = {'error': 'Unknown task type'}

        self.tasks_completed += 1
        return result

    def _calculate(self, payload):
        """Perform a calculation."""
        operation = payload.get('operation', 'add')
        a = float(payload.get('a', 0))
        b = float(payload.get('b', 0))

        operations = {
            'add': lambda x, y: x + y,
            'subtract': lambda x, y: x - y,
            'multiply': lambda x, y: x * y,
            'divide': lambda x, y: x / y if y != 0 else None
        }

        if operation in operations:
            result = operations[operation](a, b)
            return {
                'success': True,
                'result': result,
                'operation': operation
            }
        return {'success': False, 'error': 'Invalid operation'}

    def _analyze_text(self, payload):
        """Analyze text and return statistics."""
        text = payload.get('text', '')

        return {
            'success': True,
            'length': len(text),
            'words': len(text.split()),
            'lines': len(text.splitlines()),
            'uppercase': sum(1 for c in text if c.isupper()),
            'lowercase': sum(1 for c in text if c.islower())
        }

    def _hash_data(self, payload):
        """Generate a secure hash of the provided data."""
        data = payload.get('data', '')
        algorithm = payload.get('algorithm', 'sha256')

        # Only use secure hashing algorithms
        if algorithm == 'sha256':
            hash_obj = hashlib.sha256(data.encode())
        elif algorithm == 'sha512':
            hash_obj = hashlib.sha512(data.encode())
        else:
            return {'success': False, 'error': 'Unsupported algorithm. Use sha256 or sha512'}

        return {
            'success': True,
            'hash': hash_obj.hexdigest(),
            'algorithm': algorithm
        }

    def get_stats(self):
        """Get agent statistics."""
        return {
            'name': self.name,
            'tasks_completed': self.tasks_completed,
            'total_revenue': self.total_revenue,
            'uptime': 'active'
        }


def main():
    """Main function to demonstrate agent capabilities."""
    agent = SimpleAgent("TestAgent-v1")

    print(f"Agent '{agent.name}' initialized")
    print("-" * 50)

    # Example tasks
    tasks = [
        {
            'type': 'calculate',
            'payload': {'operation': 'add', 'a': 10, 'b': 5}
        },
        {
            'type': 'analyze_text',
            'payload': {'text': 'Hello World! This is a test.'}
        },
        {
            'type': 'hash_data',
            'payload': {'data': 'test123', 'algorithm': 'sha256'}
        }
    ]

    for i, task in enumerate(tasks, 1):
        print(f"\nTask {i}: {task['type']}")
        result = agent.process_task(task)
        print(f"Result: {json.dumps(result, indent=2)}")

    print("\n" + "-" * 50)
    print("Agent Statistics:")
    print(json.dumps(agent.get_stats(), indent=2))


if __name__ == "__main__":
    main()
